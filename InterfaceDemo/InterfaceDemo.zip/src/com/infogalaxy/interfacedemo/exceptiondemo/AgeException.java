package com.infogalaxy.interfacedemo.exceptiondemo;

public class AgeException extends RuntimeException{



    AgeException(String message){
        super(message);
    }

}
