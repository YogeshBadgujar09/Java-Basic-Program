package com.infogalaxy.interfacedemo;

public interface Interface2 {
    void fun1();
}
