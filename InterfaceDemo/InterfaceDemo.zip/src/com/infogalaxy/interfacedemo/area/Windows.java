package com.infogalaxy.interfacedemo.area;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Windows extends WindowAdapter{



    @Override
    public void windowIconified(WindowEvent e) {

    }

    @Override
    public void windowDeiconified(WindowEvent e) {

    }


}
