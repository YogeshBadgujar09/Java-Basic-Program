package com.infogalaxy.interfacedemo.area;

public interface IAreaInterface {
    double PI = 3.14;
    void input();
    void calculate();
    void output();
}
