package com.infogalaxy.interfacedemo.area;

public class RectArea implements IAreaInterface{
    @Override
    public void input() {

    }

    @Override
    public void calculate() {

    }

    @Override
    public void output() {

    }
}
